// Alert quando o formulário for enviado
const form = document.querySelector('form');
form.addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Obrigado por entrar em contato com o Agrinho! 🌿');
  form.reset();
});